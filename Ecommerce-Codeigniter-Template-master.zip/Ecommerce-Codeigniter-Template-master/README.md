# Ecommerce-Codeigniter-Project

Live URL: http://ecommerce.sumon-it.com/

![screencapture-ecommerce-sumon-it-1515877134667](https://user-images.githubusercontent.com/29582239/34910039-8aa70816-f8d7-11e7-8779-6382b198d6bf.png)

How to Use IT..... Go to your PHP my admin Then create a Database name ecommerce_codeigniter then import sql from under zip file Using Default configuration: username:root password:"" db_host:localhost db_name:ecommerce_codeigniter
